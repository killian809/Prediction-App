const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
app.use(express.json({ limit: '1mb' }));

// ---------------------------------------------------------------------------
// Storage: a tiny durable key-value store, backed by a JSON file on disk.
// This stands in for the artifact `window.storage` API so the frontend
// works unchanged once it's talking to this server instead.
//
// Personal data (shared=false) is namespaced per-browser using a random
// client id (see /api/client-id). Shared data (shared=true, i.e. leagues)
// is visible to everyone who has the league code, matching the original
// app's design.
// ---------------------------------------------------------------------------

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'storage.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({}));

let store = {};
try {
  store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
} catch (err) {
  console.error('Could not read storage file, starting fresh:', err);
  store = {};
}

let saveScheduled = false;
function persist() {
  if (saveScheduled) return;
  saveScheduled = true;
  // Debounce writes slightly so rapid saves don't hammer the disk.
  setTimeout(() => {
    saveScheduled = false;
    fs.writeFile(DATA_FILE, JSON.stringify(store), (err) => {
      if (err) console.error('Failed to persist storage file:', err);
    });
  }, 50);
}

function namespacedKey(clientId, key, shared) {
  return shared ? `shared:${key}` : `client:${clientId}:${key}`;
}

function requireClientId(req, res) {
  const clientId = req.get('X-Client-Id');
  if (!clientId) {
    res.status(400).json({ error: 'Missing X-Client-Id header.' });
    return null;
  }
  return clientId;
}

// Issue a random client id. The frontend generates and stores this itself
// in localStorage, but this endpoint is here in case a client needs a
// fresh one.
app.get('/api/client-id', (req, res) => {
  res.json({ clientId: crypto.randomUUID() });
});

app.get('/api/storage/:key', (req, res) => {
  const shared = req.query.shared === 'true';
  const clientId = shared ? (req.get('X-Client-Id') || 'anon') : requireClientId(req, res);
  if (clientId === null) return;

  const fullKey = namespacedKey(clientId, req.params.key, shared);
  if (!(fullKey in store)) return res.status(404).json({ error: 'Not found' });
  res.json({ key: req.params.key, value: store[fullKey], shared });
});

app.post('/api/storage/:key', (req, res) => {
  const { value, shared } = req.body || {};
  if (typeof value !== 'string') {
    return res.status(400).json({ error: 'value must be a string' });
  }
  const isShared = !!shared;
  const clientId = isShared ? (req.get('X-Client-Id') || 'anon') : requireClientId(req, res);
  if (clientId === null) return;

  const fullKey = namespacedKey(clientId, req.params.key, isShared);
  store[fullKey] = value;
  persist();
  res.json({ key: req.params.key, value, shared: isShared });
});

app.delete('/api/storage/:key', (req, res) => {
  const shared = req.query.shared === 'true';
  const clientId = shared ? (req.get('X-Client-Id') || 'anon') : requireClientId(req, res);
  if (clientId === null) return;

  const fullKey = namespacedKey(clientId, req.params.key, shared);
  const existed = fullKey in store;
  delete store[fullKey];
  persist();
  res.json({ key: req.params.key, deleted: existed, shared });
});

// ---------------------------------------------------------------------------
// Static frontend
// ---------------------------------------------------------------------------

app.use(express.static(path.join(__dirname, 'public')));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`PL Turf Predictor server running on http://localhost:${PORT}`);
});
