# PL Turf Predictor

A Premier League result-prediction app with private leagues you and your
mates can join with a share code.

## What changed from the artifact version

The app used to save data with Claude's `window.storage`, which only exists
inside Claude.ai — it can't work on a real website. This version replaces
that with:

- `server.js` — a small Express server with its own save/load API, storing
  data in `data/storage.json` on disk.
- A short shim added near the top of `public/index.html`'s `<script>` block
  that redefines `window.storage` to call this server instead. Nothing else
  in the app's logic changed.
- Personal data (your predictions, your saved club) is scoped to your
  browser via a random id in `localStorage`. League data is shared with
  anyone who has the code, same as before.

## Run it locally

```bash
npm install
npm start
```

Then open http://localhost:3000 — this serves both the site and the API,
so there's nothing else to configure.

## Put it online for friends

Any Node hosting service works. The two easiest, both with free tiers:

### Option A: Render.com
1. Push this folder to a GitHub repo.
2. On render.com: New → Web Service → connect the repo.
3. Build command: `npm install` · Start command: `npm start`
4. Add a **persistent disk** mounted at `/opt/render/project/src/data`
   (Render's free tier disks are small but this only stores small JSON —
   fine for a friend group). Without a disk, your data resets on every
   redeploy.
5. Deploy. You'll get a URL like `https://your-app.onrender.com` — share
   that with friends.

### Option B: Railway.app
1. Push to GitHub, then New Project → Deploy from repo on railway.app.
2. It auto-detects Node and runs `npm start`.
3. Add a volume mounted at `/app/data` under the service's Settings →
   Volumes, so `storage.json` survives restarts.
4. Generate a public domain under Settings → Networking.

Both platforms are free for light use like this. If a friend group outgrows
free-tier limits later, a $5-6/mo VPS (Fly.io, DigitalOcean) works too — same
`npm install && npm start`, just keep the `data/` folder on a persistent
volume.

## "Download it as an app"

There's a `manifest.json` and icon wired in, so once it's live at a real
URL, friends can open it in Chrome/Safari on their phone and use
"Add to Home Screen" (Android) or Share → "Add to Home Screen" (iOS) — it
launches full-screen like a native app. No app store submission needed.

## Note on `server.js` you originally had

The other file you uploaded (an in-memory "Banter Engine" voting API) isn't
used by this app at all — it looked like it was from a different project.
It also had a bug that would crash on invalid votes:
`res.status, (400).json(...)` (a stray comma) — should be
`res.status(400).json(...)`. Flagging it in case you still need that one for
something else.
